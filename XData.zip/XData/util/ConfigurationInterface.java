package util;

public interface ConfigurationInterface {
	public String getPropetyValue(String propertyName);
}
