package generateConstraints;

public class TupleRange
{
    public int start;
    public int end;
    
    public TupleRange(int x, int y){
    	this.start = x;
    	this.end = y;
    }
}